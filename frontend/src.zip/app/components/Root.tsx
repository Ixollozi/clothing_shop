import { Outlet, Link, useLocation } from "react-router";
import { CartProvider, useCart } from "../context/CartContext";
import { ShoppingBag, Menu, X } from "lucide-react";
import { useState, useEffect } from "react";

function Navigation() {
  const location = useLocation();
  const { getTotalItems } = useCart();
  const totalItems = getTotalItems();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const isHome = location.pathname === "/";

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  const links = [
    { path: "/catalog", label: "Каталог" },
    { path: "/about", label: "О нас" },
    { path: "/faq", label: "FAQ" },
  ];

  const navBg = isHome && !scrolled ? "bg-transparent" : "bg-[#FDFAF7]";
  const navBorder = scrolled || !isHome ? "border-b border-[#E8DED4]" : "";
  const textColor = isHome && !scrolled ? "text-white" : "text-[#1C1714]";
  const logoColor = isHome && !scrolled ? "text-white" : "text-[#1C1714]";

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${navBg} ${navBorder}`}
        style={{ fontFamily: "'DM Sans', sans-serif" }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="flex justify-between items-center h-16 md:h-20">
            {/* Logo */}
            <Link
              to="/"
              className={`tracking-[0.25em] uppercase text-sm ${logoColor} transition-colors duration-300`}
              style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.1rem", fontWeight: 600, letterSpacing: "0.3em" }}
            >
              Argillia
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center space-x-10">
              {links.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`text-xs tracking-widest uppercase transition-all duration-300 relative group ${textColor}`}
                  style={{ letterSpacing: "0.15em", fontSize: "0.7rem" }}
                >
                  {link.label}
                  <span
                    className={`absolute -bottom-1 left-0 h-px transition-all duration-300 ${
                      location.pathname.startsWith(link.path)
                        ? "w-full bg-[#B85538]"
                        : "w-0 group-hover:w-full bg-[#B85538]"
                    }`}
                  />
                </Link>
              ))}
            </div>

            {/* Cart + Mobile Menu */}
            <div className="flex items-center space-x-6">
              <Link
                to="/cart"
                className={`relative transition-colors duration-300 flex items-center gap-2 ${textColor}`}
              >
                <ShoppingBag className="w-5 h-5" />
                {totalItems > 0 && (
                  <span className="absolute -top-2 -right-2 bg-[#B85538] text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center">
                    {totalItems}
                  </span>
                )}
              </Link>
              <button
                className={`md:hidden transition-colors duration-300 ${textColor}`}
                onClick={() => setMenuOpen(!menuOpen)}
              >
                {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      {menuOpen && (
        <div
          className="fixed inset-0 z-40 bg-[#1C1714] flex flex-col items-center justify-center space-y-10"
          style={{ fontFamily: "'Cormorant Garamond', serif" }}
        >
          {[{ path: "/", label: "Главная" }, ...links].map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className="text-white text-4xl tracking-widest hover:text-[#D4895A] transition-colors"
              style={{ fontStyle: "italic" }}
            >
              {link.label}
            </Link>
          ))}
        </div>
      )}
    </>
  );
}

function Footer() {
  return (
    <footer
      className="bg-[#1C1714] text-[#A99A8C]"
      style={{ fontFamily: "'DM Sans', sans-serif" }}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="md:col-span-2">
            <p
              className="text-white tracking-[0.3em] uppercase mb-6 text-lg"
              style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600 }}
            >
              Argillia
            </p>
            <p className="text-sm leading-relaxed max-w-xs" style={{ lineHeight: 1.8 }}>
              Керамика и фарфор ручной работы — изделия, которые хранят тепло мастера и украшают вашу жизнь.
            </p>
          </div>
          <div>
            <p className="text-white text-xs tracking-widest uppercase mb-6" style={{ fontSize: "0.65rem" }}>
              Навигация
            </p>
            <div className="space-y-3">
              {[
                { to: "/catalog", label: "Каталог" },
                { to: "/about", label: "О нас" },
                { to: "/faq", label: "FAQ" },
                { to: "/cart", label: "Корзина" },
              ].map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className="block text-sm hover:text-white transition-colors"
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>
          <div>
            <p className="text-white text-xs tracking-widest uppercase mb-6" style={{ fontSize: "0.65rem" }}>
              Контакты
            </p>
            <div className="space-y-3 text-sm">
              <p>info@argillia.ru</p>
              <p>+7 (999) 123-45-67</p>
              <p className="leading-relaxed">Москва,<br />ул. Мастеров, 12</p>
            </div>
          </div>
        </div>
        <div className="border-t border-[#2E2520] pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs" style={{ fontSize: "0.65rem", letterSpacing: "0.1em" }}>
            © 2026 ARGILLIA. ВСЕ ПРАВА ЗАЩИЩЕНЫ.
          </p>
          <p className="text-xs" style={{ fontSize: "0.65rem", letterSpacing: "0.1em" }}>
            СДЕЛАНО С ЛЮБОВЬЮ К РЕМЕСЛУ
          </p>
        </div>
      </div>
    </footer>
  );
}

export function Root() {
  return (
    <CartProvider>
      <div className="min-h-screen flex flex-col bg-[#F7F3EE]">
        <Navigation />
        <main className="flex-1">
          <Outlet />
        </main>
        <Footer />
      </div>
    </CartProvider>
  );
}
