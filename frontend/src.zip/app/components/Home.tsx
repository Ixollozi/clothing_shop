import { Link } from "react-router";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { products } from "../data/products";

const heroImage = "https://images.unsplash.com/photo-1763824371988-8c8eb3d13eff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjZXJhbWljJTIwcG90dGVyeSUyMGFydGlzYW4lMjB3b3Jrc2hvcHxlbnwxfHx8fDE3Nzc4Mzk0MTV8MA&ixlib=rb-4.1.0&q=80&w=1080";
const aboutImage = "https://images.unsplash.com/photo-1772487488987-425a4a0c1499?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGF5JTIwcG90dGVyeSUyMGhhbmRzJTIwc2hhcGluZ3xlbnwxfHx8fDE3Nzc4Mzk0MTh8MA&ixlib=rb-4.1.0&q=80&w=1080";

const featured = products.filter((p) => p.isBestseller).slice(0, 4);
const newArrivals = products.filter((p) => p.isNew).slice(0, 3);

export function Home() {
  return (
    <div style={{ fontFamily: "'DM Sans', sans-serif" }}>
      {/* ── HERO ── */}
      <section className="relative h-screen min-h-[600px] overflow-hidden">
        <img
          src={heroImage}
          alt="Мастерская ARGILLIA"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1C1714]/80 via-[#1C1714]/50 to-transparent" />

        <div className="relative z-10 h-full flex flex-col justify-end pb-20 px-6 lg:px-16 max-w-7xl mx-auto">
          <div className="max-w-2xl">
            <p
              className="text-[#D4895A] mb-4 tracking-[0.3em] uppercase"
              style={{ fontSize: "0.7rem", fontFamily: "'DM Sans', sans-serif" }}
            >
              Ручная работа · Россия · с 2011
            </p>
            <h1
              className="text-white mb-6"
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: "clamp(3rem, 7vw, 6rem)",
                fontWeight: 300,
                lineHeight: 1.05,
                letterSpacing: "-0.01em",
              }}
            >
              Искусство,
              <br />
              <em>рождённое</em>
              <br />
              из глины
            </h1>
            <p className="text-white/70 mb-10 max-w-md" style={{ lineHeight: 1.8, fontSize: "0.95rem" }}>
              Каждое изделие — диалог мастера с материалом. Фарфор и керамика, хранящие тепло рук.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/catalog"
                className="inline-flex items-center gap-3 bg-[#B85538] text-white px-8 py-4 hover:bg-[#9E4630] transition-colors duration-300 text-sm tracking-wider"
                style={{ letterSpacing: "0.1em" }}
              >
                СМОТРЕТЬ КАТАЛОГ
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/about"
                className="inline-flex items-center gap-3 border border-white/50 text-white px-8 py-4 hover:bg-white/10 transition-colors duration-300 text-sm tracking-wider"
                style={{ letterSpacing: "0.1em" }}
              >
                О МАСТЕРСКОЙ
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 right-12 hidden md:flex flex-col items-center gap-2 text-white/50">
          <div className="w-px h-12 bg-white/30 animate-pulse" />
          <span style={{ fontSize: "0.6rem", letterSpacing: "0.2em", writingMode: "vertical-rl" }}>
            SCROLL
          </span>
        </div>
      </section>

      {/* ── STATS BAND ── */}
      <section className="bg-[#1C1714] py-8">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { num: "15+", label: "лет мастерства" },
              { num: "3 000+", label: "изделий создано" },
              { num: "100%", label: "ручная работа" },
              { num: "48ч", label: "бережная доставка" },
            ].map((stat) => (
              <div key={stat.label}>
                <p
                  className="text-[#D4895A] mb-1"
                  style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.75rem", fontWeight: 300 }}
                >
                  {stat.num}
                </p>
                <p className="text-[#A99A8C] text-xs tracking-widest uppercase" style={{ fontSize: "0.65rem" }}>
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── BESTSELLERS ── */}
      <section className="py-24 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-14">
            <div>
              <p className="text-[#B85538] text-xs tracking-widest uppercase mb-3" style={{ fontSize: "0.65rem" }}>
                Популярное
              </p>
              <h2
                style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontSize: "clamp(2rem, 4vw, 3rem)",
                  fontWeight: 300,
                  color: "#1C1714",
                  lineHeight: 1.1,
                }}
              >
                Хиты коллекции
              </h2>
            </div>
            <Link
              to="/catalog"
              className="hidden md:inline-flex items-center gap-2 text-[#B85538] hover:gap-4 transition-all duration-300 text-sm"
              style={{ letterSpacing: "0.08em" }}
            >
              Весь каталог <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {featured.map((product, i) => (
              <Link
                key={product.id}
                to={`/product/${product.id}`}
                className="group block"
              >
                <div className="relative overflow-hidden bg-[#EDE5DA] mb-4" style={{ aspectRatio: i === 0 ? "3/4" : "1/1" }}>
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-[#1C1714]/0 group-hover:bg-[#1C1714]/20 transition-colors duration-500" />
                  <div className="absolute top-3 left-3">
                    {product.isNew && (
                      <span className="bg-[#B85538] text-white px-2 py-1 text-[10px] tracking-widest uppercase">
                        Новинка
                      </span>
                    )}
                    {product.isBestseller && !product.isNew && (
                      <span className="bg-[#1C1714] text-white px-2 py-1 text-[10px] tracking-widest uppercase">
                        Хит
                      </span>
                    )}
                  </div>
                  <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="bg-white w-9 h-9 flex items-center justify-center">
                      <ArrowUpRight className="w-4 h-4 text-[#1C1714]" />
                    </div>
                  </div>
                </div>
                <p className="text-[#6B5E54] text-xs tracking-widest uppercase mb-1" style={{ fontSize: "0.6rem" }}>
                  {product.category}
                </p>
                <p className="text-[#1C1714] mb-2" style={{ fontSize: "0.9rem", lineHeight: 1.4 }}>
                  {product.name}
                </p>
                <p className="text-[#B85538]" style={{ fontSize: "0.9rem" }}>
                  {product.price.toLocaleString("ru-RU")} ₽
                </p>
              </Link>
            ))}
          </div>

          <div className="mt-10 md:hidden text-center">
            <Link
              to="/catalog"
              className="inline-flex items-center gap-2 text-[#B85538] text-sm border-b border-[#B85538] pb-1"
            >
              Смотреть всё <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ── ABOUT SPLIT ── */}
      <section className="grid grid-cols-1 md:grid-cols-2 min-h-[500px]">
        <div className="relative overflow-hidden min-h-[400px]">
          <img
            src={aboutImage}
            alt="Процесс создания"
            className="absolute inset-0 w-full h-full object-cover"
          />
        </div>
        <div className="bg-[#1C1714] flex items-center px-10 lg:px-16 py-20">
          <div>
            <p className="text-[#D4895A] text-xs tracking-widest uppercase mb-6" style={{ fontSize: "0.65rem" }}>
              Наша философия
            </p>
            <h2
              className="text-white mb-6"
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: "clamp(1.8rem, 3vw, 2.8rem)",
                fontWeight: 300,
                lineHeight: 1.2,
              }}
            >
              Мастерство,
              <br />
              <em>переданное сквозь века</em>
            </h2>
            <p className="text-[#A99A8C] mb-8" style={{ lineHeight: 1.9, fontSize: "0.9rem" }}>
              Мы убеждены: настоящая красота рождается медленно. Каждое изделие проходит шесть этапов ручного труда — от замеса глины до финального обжига. Никакой конвейер не способен создать то, что делают руки мастера.
            </p>
            <Link
              to="/about"
              className="inline-flex items-center gap-3 text-white border-b border-[#D4895A] pb-1 text-sm hover:text-[#D4895A] transition-colors"
              style={{ letterSpacing: "0.08em" }}
            >
              Наша история <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ── NEW ARRIVALS ── */}
      <section className="py-24 px-6 lg:px-12 bg-[#EDE5DA]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-14">
            <p className="text-[#B85538] text-xs tracking-widest uppercase mb-3" style={{ fontSize: "0.65rem" }}>
              Только появились
            </p>
            <h2
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: "clamp(2rem, 4vw, 3rem)",
                fontWeight: 300,
                color: "#1C1714",
                lineHeight: 1.1,
              }}
            >
              Новинки
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {newArrivals.map((product) => (
              <Link
                key={product.id}
                to={`/product/${product.id}`}
                className="group block bg-[#F7F3EE]"
              >
                <div className="relative overflow-hidden" style={{ aspectRatio: "4/5" }}>
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute top-3 left-3">
                    <span className="bg-[#B85538] text-white px-2 py-1 text-[10px] tracking-widest uppercase">
                      Новинка
                    </span>
                  </div>
                </div>
                <div className="p-5">
                  <p className="text-[#6B5E54] text-xs tracking-widest uppercase mb-2" style={{ fontSize: "0.6rem" }}>
                    {product.category}
                  </p>
                  <p className="text-[#1C1714] mb-2" style={{ fontSize: "0.95rem" }}>
                    {product.name}
                  </p>
                  <p className="text-[#B85538]" style={{ fontSize: "0.9rem" }}>
                    {product.price.toLocaleString("ru-RU")} ₽
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── VALUES ── */}
      <section className="py-24 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              {
                icon: "◌",
                title: "Ручная работа",
                text: "Каждое изделие создаётся вручную опытными мастерами. Мы намеренно отказались от конвейера.",
              },
              {
                icon: "◎",
                title: "Живые материалы",
                text: "Только природная глина, экологичные пигменты и проверенные временем глазури.",
              },
              {
                icon: "◈",
                title: "Доставка без потерь",
                text: "Бережная упаковка каждого изделия с тройной защитой. Вы получите шедевр целым.",
              },
            ].map((val) => (
              <div key={val.title} className="flex flex-col">
                <p
                  className="text-[#B85538] mb-6"
                  style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "2rem" }}
                >
                  {val.icon}
                </p>
                <p
                  className="text-[#1C1714] mb-3"
                  style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.3rem", fontWeight: 400 }}
                >
                  {val.title}
                </p>
                <p className="text-[#6B5E54] text-sm" style={{ lineHeight: 1.8 }}>
                  {val.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA BANNER ── */}
      <section className="relative overflow-hidden bg-[#B85538] py-20 px-6 lg:px-12 text-center">
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: "radial-gradient(circle at 30% 50%, #fff 0%, transparent 50%), radial-gradient(circle at 70% 50%, #fff 0%, transparent 50%)",
          }}
        />
        <div className="relative z-10 max-w-2xl mx-auto">
          <p className="text-white/70 text-xs tracking-widest uppercase mb-4" style={{ fontSize: "0.65rem" }}>
            Индивидуальный заказ
          </p>
          <h2
            className="text-white mb-6"
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: "clamp(1.8rem, 4vw, 3rem)",
              fontWeight: 300,
              lineHeight: 1.2,
            }}
          >
            Хотите что-то<br />
            <em>по-настоящему уникальное?</em>
          </h2>
          <p className="text-white/80 mb-10 text-sm" style={{ lineHeight: 1.8 }}>
            Мы создаём изделия по индивидуальным эскизам. Ваш размер, ваши цвета, ваша история.
          </p>
          <Link
            to="/faq"
            className="inline-flex items-center gap-3 bg-white text-[#B85538] px-8 py-4 hover:bg-[#F7F3EE] transition-colors text-sm tracking-wider"
            style={{ letterSpacing: "0.1em" }}
          >
            УЗНАТЬ БОЛЬШЕ <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>
    </div>
  );
}
