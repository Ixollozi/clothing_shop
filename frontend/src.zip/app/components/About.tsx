import { Link } from "react-router";
import { ArrowRight } from "lucide-react";

const workshopImage = "https://images.unsplash.com/photo-1763824371988-8c8eb3d13eff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjZXJhbWljJTIwcG90dGVyeSUyMGFydGlzYW4lMjB3b3Jrc2hvcHxlbnwxfHx8fDE3Nzc4Mzk0MTV8MA&ixlib=rb-4.1.0&q=80&w=1080";
const handsImage = "https://images.unsplash.com/photo-1772487488987-425a4a0c1499?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGF5JTIwcG90dGVyeSUyMGhhbmRzJTIwc2hhcGluZ3xlbnwxfHx8fDE3Nzc4Mzk0MTh8MA&ixlib=rb-4.1.0&q=80&w=1080";

const steps = [
  { num: "01", title: "Замысел", text: "Каждое изделие начинается с идеи. Мы создаём эскиз, изучаем форму, продумываем пропорции." },
  { num: "02", title: "Подготовка глины", text: "Глина вымешивается вручную, чтобы удалить пузыри воздуха. Это требует силы и терпения." },
  { num: "03", title: "Формование", text: "На гончарном круге или вручную мастер придаёт глине форму. Главный момент — живой контакт." },
  { num: "04", title: "Первый обжиг", text: "Бисквитный обжиг при 900°C. Изделие становится твёрдым, готовым к глазурованию." },
  { num: "05", title: "Роспись и глазурь", text: "Художник наносит орнамент и глазурь. Каждый мазок — вручную. Каждое изделие — уникально." },
  { num: "06", title: "Финальный обжиг", text: "При 1280°C глазурь плавится и становится вечной. Готово. Это займёт у вас 5 дней." },
];

export function About() {
  return (
    <div className="bg-[#F7F3EE]" style={{ fontFamily: "'DM Sans', sans-serif" }}>
      {/* Hero */}
      <div className="relative overflow-hidden min-h-[70vh] flex items-end">
        <img
          src={workshopImage}
          alt="Мастерская Argillia"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1C1714] via-[#1C1714]/40 to-transparent" />
        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12 pb-20 pt-36 w-full">
          <p className="text-[#D4895A] text-xs tracking-widest uppercase mb-5" style={{ fontSize: "0.65rem" }}>
            О нас
          </p>
          <h1
            className="text-white max-w-3xl"
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: "clamp(2.5rem, 5vw, 5rem)",
              fontWeight: 300,
              lineHeight: 1.05,
            }}
          >
            Мастерская,
            <br />
            <em>где глина обретает душу</em>
          </h1>
        </div>
      </div>

      {/* Intro */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div>
            <p className="text-[#B85538] text-xs tracking-widest uppercase mb-5" style={{ fontSize: "0.65rem" }}>
              Наша история
            </p>
            <h2
              className="text-[#1C1714] mb-6"
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: "clamp(1.8rem, 3vw, 2.8rem)",
                fontWeight: 300,
                lineHeight: 1.2,
              }}
            >
              15 лет. Тысячи изделий.
              <br />
              Одна страсть.
            </h2>
            <p className="text-[#6B5E54] mb-6" style={{ lineHeight: 1.9, fontSize: "0.9rem" }}>
              ARGILLIA была основана в 2011 году группой мастеров, влюблённых в традиционное ремесло. Мы начали в небольшой мастерской на окраине Москвы — с одним гончарным кругом и огромным желанием создавать прекрасное.
            </p>
            <p className="text-[#6B5E54]" style={{ lineHeight: 1.9, fontSize: "0.9rem" }}>
              Сегодня наши изделия украшают дома по всей России. Но главное не изменилось: каждая вещь создаётся вручную, с терпением и вниманием к каждому миллиметру.
            </p>
          </div>
          <div className="relative">
            <img
              src={handsImage}
              alt="Руки мастера"
              className="w-full object-cover"
              style={{ aspectRatio: "4/3" }}
            />
            <div
              className="absolute -bottom-6 -left-6 bg-[#B85538] text-white p-8 hidden md:block"
              style={{ width: "180px" }}
            >
              <p
                style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "2.5rem", fontWeight: 300, lineHeight: 1 }}
              >
                2011
              </p>
              <p className="text-white/70 text-xs mt-1" style={{ fontSize: "0.65rem", letterSpacing: "0.1em" }}>
                ГОД ОСНОВАНИЯ
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Values */}
      <div className="bg-[#1C1714] py-20 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-[#D4895A] text-xs tracking-widest uppercase mb-4" style={{ fontSize: "0.65rem" }}>
              Что нас определяет
            </p>
            <h2
              className="text-white"
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: "clamp(1.8rem, 3vw, 2.8rem)",
                fontWeight: 300,
              }}
            >
              Наши ценности
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: "◌", title: "Мастерство", text: "Только опытные мастера, прошедшие годы обучения традиционным техникам." },
              { icon: "◎", title: "Уникальность", text: "Каждое изделие создаётся в единственном экземпляре. Одинаковых не бывает." },
              { icon: "◈", title: "Экология", text: "Природная глина, безопасные пигменты, экологичная упаковка без пластика." },
              { icon: "◉", title: "Честность", text: "Мы не преувеличиваем. Что сделано — сделано руками. Всегда." },
            ].map((val) => (
              <div key={val.title} className="border-t border-[#2E2520] pt-8">
                <p
                  className="text-[#D4895A] mb-4"
                  style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.8rem" }}
                >
                  {val.icon}
                </p>
                <p
                  className="text-white mb-3"
                  style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.2rem", fontWeight: 400 }}
                >
                  {val.title}
                </p>
                <p className="text-[#A99A8C] text-sm" style={{ lineHeight: 1.8, fontSize: "0.85rem" }}>
                  {val.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Process */}
      <div className="py-20 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="mb-14">
            <p className="text-[#B85538] text-xs tracking-widest uppercase mb-4" style={{ fontSize: "0.65rem" }}>
              От замысла до вашего дома
            </p>
            <h2
              className="text-[#1C1714]"
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: "clamp(1.8rem, 3vw, 2.8rem)",
                fontWeight: 300,
              }}
            >
              Как создаётся изделие
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {steps.map((step) => (
              <div key={step.num} className="flex gap-6">
                <p
                  className="text-[#E0D5C8] flex-shrink-0"
                  style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "2.5rem", fontWeight: 300, lineHeight: 1 }}
                >
                  {step.num}
                </p>
                <div className="border-t border-[#E0D5C8] pt-4 flex-1">
                  <p
                    className="text-[#1C1714] mb-3"
                    style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.15rem", fontWeight: 400 }}
                  >
                    {step.title}
                  </p>
                  <p className="text-[#6B5E54] text-sm" style={{ lineHeight: 1.8 }}>
                    {step.text}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="bg-[#EDE5DA] py-20 px-6 lg:px-12 text-center">
        <div className="max-w-xl mx-auto">
          <h2
            className="text-[#1C1714] mb-6"
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: "clamp(1.8rem, 3vw, 2.5rem)",
              fontWeight: 300,
            }}
          >
            Готовы выбрать своё изделие?
          </h2>
          <p className="text-[#6B5E54] text-sm mb-10" style={{ lineHeight: 1.8 }}>
            Загляните в каталог — каждый предмет создан с любовью и ждёт своего нового дома.
          </p>
          <Link
            to="/catalog"
            className="inline-flex items-center gap-3 bg-[#1C1714] text-white px-10 py-4 hover:bg-[#B85538] transition-colors text-xs tracking-widest uppercase"
            style={{ letterSpacing: "0.15em", fontSize: "0.7rem" }}
          >
            Смотреть каталог <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
