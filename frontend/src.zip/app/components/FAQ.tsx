import { useState } from "react";
import { Plus, Minus } from "lucide-react";
import { Link } from "react-router";

interface FAQItemProps {
  question: string;
  answer: string;
  isOpen: boolean;
  onToggle: () => void;
  index: number;
}

function FAQItem({ question, answer, isOpen, onToggle, index }: FAQItemProps) {
  return (
    <div className="border-b border-[#E0D5C8]">
      <button
        onClick={onToggle}
        className="w-full py-6 flex items-start justify-between gap-8 text-left group"
      >
        <div className="flex items-start gap-6">
          <span
            className="text-[#D5C9BC] flex-shrink-0 pt-0.5"
            style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "0.9rem" }}
          >
            {String(index + 1).padStart(2, "0")}
          </span>
          <span
            className={`transition-colors duration-200 ${isOpen ? "text-[#B85538]" : "text-[#1C1714] group-hover:text-[#B85538]"}`}
            style={{ fontSize: "0.95rem", lineHeight: 1.5 }}
          >
            {question}
          </span>
        </div>
        <div className="flex-shrink-0 mt-1">
          {isOpen ? (
            <Minus className="w-4 h-4 text-[#B85538]" />
          ) : (
            <Plus className="w-4 h-4 text-[#A99A8C]" />
          )}
        </div>
      </button>
      {isOpen && (
        <div className="pl-12 pb-6">
          <p className="text-[#6B5E54] text-sm" style={{ lineHeight: 1.9 }}>
            {answer}
          </p>
        </div>
      )}
    </div>
  );
}

const faqs = [
  {
    category: "Заказ и оплата",
    items: [
      {
        question: "Как оформить заказ?",
        answer: "Добавьте понравившиеся товары в корзину, перейдите в корзину и нажмите «Оформить заказ». Заполните данные для доставки и выберите способ оплаты. Мы свяжемся с вами для подтверждения.",
      },
      {
        question: "Какие способы оплаты доступны?",
        answer: "Мы принимаем оплату банковскими картами (Visa, MasterCard, МИР), через систему быстрых платежей (СБП), а также электронными кошельками ЮMoney и QIWI.",
      },
      {
        question: "Можно ли заказать изделие по индивидуальному дизайну?",
        answer: "Да, мы принимаем индивидуальные заказы. Напишите нам на info@argillia.ru с описанием идеи и предпочтительными размерами. Мы обсудим детали и стоимость в течение 1–2 рабочих дней.",
      },
    ],
  },
  {
    category: "Доставка",
    items: [
      {
        question: "Сколько времени занимает доставка?",
        answer: "По Москве и МО — 1–2 рабочих дня. По России — 3–7 рабочих дней в зависимости от региона. Мы используем СДЭК, Почту России и курьерские службы. Все хрупкие изделия упакованы с тройной защитой.",
      },
      {
        question: "Как упаковываются изделия?",
        answer: "Каждое изделие обёртывается в несколько слоёв пузырчатой плёнки, затем помещается в коробку с наполнителем из переработанного картона. Сверху — фирменная крафт-бумага и открытка от мастера.",
      },
      {
        question: "Можно ли самовывоз?",
        answer: "Да, наша мастерская и шоу-рум находятся в Москве (ул. Мастеров, 12). Самовывоз возможен по предварительной записи в будни с 10:00 до 18:00.",
      },
    ],
  },
  {
    category: "Товары и качество",
    items: [
      {
        question: "Все ли изделия сделаны вручную?",
        answer: "Абсолютно все. Мы принципиально не используем промышленное тиражирование. Каждое изделие создаётся мастером от начала до конца — от замеса глины до финального обжига.",
      },
      {
        question: "Безопасны ли изделия для использования с пищей?",
        answer: "Да. Мы используем только сертифицированные пищевые глазури, не содержащие свинца и кадмия. Все изделия соответствуют российским санитарным нормам для пищевой посуды.",
      },
      {
        question: "Как ухаживать за керамикой и фарфором?",
        answer: "Рекомендуем мыть вручную тёплой водой с мягким средством. Большинство изделий можно мыть в посудомоечной машине, но ручная мойка продлит жизнь росписи. Избегайте резких перепадов температур.",
      },
      {
        question: "Предоставляете ли вы гарантию?",
        answer: "Мы гарантируем качество каждого изделия. Если вы обнаружили скрытый брак (трещина, отслоение глазури, дефект обжига) — свяжитесь с нами в течение 30 дней. Мы заменим товар или вернём деньги.",
      },
    ],
  },
  {
    category: "Возврат",
    items: [
      {
        question: "Можно ли вернуть товар?",
        answer: "Да, в течение 14 дней с момента получения, если изделие не использовалось и сохранена оригинальная упаковка. Товары с браком принимаем в течение 30 дней без каких-либо условий.",
      },
      {
        question: "Что делать, если изделие повредилось при доставке?",
        answer: "Сфотографируйте повреждение, не выбрасывая упаковку, и напишите нам на info@argillia.ru в течение 48 часов. Мы немедленно вышлем замену или вернём деньги — полностью.",
      },
    ],
  },
];

export function FAQ() {
  const [openItem, setOpenItem] = useState<string | null>(null);

  const toggle = (key: string) => {
    setOpenItem(openItem === key ? null : key);
  };

  return (
    <div className="bg-[#F7F3EE] min-h-screen" style={{ fontFamily: "'DM Sans', sans-serif" }}>
      {/* Header */}
      <div className="bg-[#1C1714] pt-32 pb-16 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto">
          <p className="text-[#D4895A] text-xs tracking-widest uppercase mb-4" style={{ fontSize: "0.65rem" }}>
            Помощь
          </p>
          <h1
            className="text-white max-w-xl"
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: "clamp(2.5rem, 5vw, 4.5rem)",
              fontWeight: 300,
              lineHeight: 1.05,
            }}
          >
            Часто задаваемые
            <br />
            <em>вопросы</em>
          </h1>
        </div>
      </div>

      {/* FAQ Content */}
      <div className="max-w-4xl mx-auto px-6 lg:px-12 py-16">
        {faqs.map((group) => (
          <div key={group.category} className="mb-16">
            <p
              className="text-[#B85538] text-xs tracking-widest uppercase mb-8"
              style={{ fontSize: "0.65rem" }}
            >
              {group.category}
            </p>
            <div>
              {group.items.map((faq, idx) => {
                const key = `${group.category}-${idx}`;
                return (
                  <FAQItem
                    key={key}
                    question={faq.question}
                    answer={faq.answer}
                    isOpen={openItem === key}
                    onToggle={() => toggle(key)}
                    index={idx}
                  />
                );
              })}
            </div>
          </div>
        ))}

        {/* Contact Block */}
        <div className="bg-[#1C1714] p-10 md:p-14 mt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <div>
              <p className="text-[#D4895A] text-xs tracking-widest uppercase mb-4" style={{ fontSize: "0.65rem" }}>
                Остались вопросы?
              </p>
              <h2
                className="text-white mb-4"
                style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontSize: "clamp(1.5rem, 2.5vw, 2rem)",
                  fontWeight: 300,
                }}
              >
                Мы всегда на связи
              </h2>
              <p className="text-[#A99A8C] text-sm" style={{ lineHeight: 1.8 }}>
                Напишите нам или позвоните — ответим в течение нескольких часов в рабочее время.
              </p>
            </div>
            <div className="space-y-5">
              <div>
                <p className="text-[#6B5E54] text-xs tracking-widest uppercase mb-1" style={{ fontSize: "0.6rem" }}>
                  Email
                </p>
                <a href="mailto:info@argillia.ru" className="text-white hover:text-[#D4895A] transition-colors text-sm">
                  info@argillia.ru
                </a>
              </div>
              <div>
                <p className="text-[#6B5E54] text-xs tracking-widest uppercase mb-1" style={{ fontSize: "0.6rem" }}>
                  Телефон
                </p>
                <a href="tel:+79991234567" className="text-white hover:text-[#D4895A] transition-colors text-sm">
                  +7 (999) 123-45-67
                </a>
              </div>
              <div>
                <p className="text-[#6B5E54] text-xs tracking-widest uppercase mb-1" style={{ fontSize: "0.6rem" }}>
                  Режим работы
                </p>
                <p className="text-white text-sm">Пн–Пт, 10:00–18:00</p>
              </div>
              <Link
                to="/catalog"
                className="inline-flex items-center gap-2 text-[#D4895A] text-xs tracking-widest uppercase border-b border-[#D4895A] pb-1 hover:text-white hover:border-white transition-colors mt-2"
                style={{ fontSize: "0.65rem" }}
              >
                Смотреть каталог →
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
