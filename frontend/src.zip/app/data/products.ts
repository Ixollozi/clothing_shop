export interface ProductData {
  id: number;
  name: string;
  price: number;
  image: string;
  description: string;
  category: string;
  material: string;
  dimensions: string;
  inStock: boolean;
  isNew?: boolean;
  isBestseller?: boolean;
}

export const products: ProductData[] = [
  // Вазы
  {
    id: 1,
    name: "Ваза «Белый пион»",
    price: 4500,
    image: "https://images.unsplash.com/photo-1723779235394-2e406c604269?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjZXJhbWljJTIwcG9yY2VsYWluJTIwcG90dGVyeXxlbnwxfHx8fDE3Nzc4Mzg5MDR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Элегантная фарфоровая ваза с ручной росписью в виде пионов. Создана с применением многовекового мастерства и современной эстетики. Каждая линия нанесена вручную — ни одного изделия, похожего на другое.",
    category: "Вазы",
    material: "Фарфор",
    dimensions: "Высота: 30 см, Диаметр: 15 см",
    inStock: true,
    isBestseller: true,
  },
  {
    id: 2,
    name: "Ваза «Терракота»",
    price: 3800,
    image: "https://images.unsplash.com/photo-1723779233339-17335cd7c562?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxjZXJhbWljJTIwcG9yY2VsYWluJTIwcG90dGVyeXxlbnwxfHx8fDE3Nzc4Mzg5MDR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Изящная керамическая ваза с цветочным узором в тёплых земляных тонах. Органичная форма подчёркивает природный характер материала.",
    category: "Вазы",
    material: "Керамика",
    dimensions: "Высота: 28 см, Диаметр: 14 см",
    inStock: true,
  },
  {
    id: 3,
    name: "Ваза «Императрица»",
    price: 7200,
    image: "https://images.unsplash.com/photo-1723779233741-8ead9562bfa5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwzfHxjZXJhbWljJTIwcG9yY2VsYWluJTIwcG90dGVyeXxlbnwxfHx8fDE3Nzc4Mzg5MDR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Роскошная ваза с традиционным орнаментом, вдохновлённым императорским фарфором. Уникальное изделие премиум-класса для коллекционеров и ценителей.",
    category: "Вазы",
    material: "Фарфор",
    dimensions: "Высота: 35 см, Диаметр: 18 см",
    inStock: true,
    isNew: true,
  },
  {
    id: 4,
    name: "Ваза «Сакура»",
    price: 5500,
    image: "https://images.unsplash.com/photo-1752718071652-c3139c51c22b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjZXJhbWljJTIwdmFzZSUyMGZsb3dlcnMlMjBob21lJTIwZGVjb3J8ZW58MXx8fHwxNzc3ODM5NDIyfDA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Нежная ваза с росписью в японском стиле. Тонкий фарфор, просвечивающий на свету — вершина керамического искусства.",
    category: "Вазы",
    material: "Фарфор",
    dimensions: "Высота: 32 см, Диаметр: 14 см",
    inStock: true,
    isNew: true,
  },
  // Чашки и кружки
  {
    id: 5,
    name: "Чашка «Утренний туман»",
    price: 1800,
    image: "https://images.unsplash.com/photo-1765808693805-adcc532b36c9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3JjZWxhaW4lMjBjb2ZmZWUlMjBtdWclMjBsdXh1cnklMjBob21lfGVufDF8fHx8MTc3NzgzOTQyMXww&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Фарфоровая чашка с нежным матовым покрытием и удобной ручкой. Идеальна для утреннего кофе или чая. Безопасна для посудомоечной машины.",
    category: "Чашки",
    material: "Фарфор",
    dimensions: "Объём: 250 мл, Высота: 8 см",
    inStock: true,
    isBestseller: true,
  },
  {
    id: 6,
    name: "Набор «Чайная церемония»",
    price: 8900,
    image: "https://images.unsplash.com/photo-1776972334890-018cb3b3e3c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjZXJhbWljJTIwdGVhJTIwc2V0JTIwaGFuZG1hZGUlMjBzdHVkaW98ZW58MXx8fHwxNzc3ODM5NDE1fDA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Полный набор для чайной церемонии: заварник + 4 чашки. Вдохновлён японской традицией ваби-саби. Каждый предмет создан вручную — поверхность хранит следы мастера.",
    category: "Чашки",
    material: "Керамика",
    dimensions: "Заварник 600 мл, Чашки 120 мл",
    inStock: true,
    isNew: true,
    isBestseller: true,
  },
  {
    id: 7,
    name: "Кружка «Земля»",
    price: 2200,
    image: "https://images.unsplash.com/photo-1723779233807-0a44335f9cac?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxMHx8Y2VyYW1pYyUyMHBvcmNlbGFpbiUyMHBvdHRlcnl8ZW58MXx8fHwxNzc3ODM4OTA0fDA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Большая кружка из грубой керамики с тёплой терракотовой глазурью. Массивная, тёплая, уютная — как объятие в холодный день.",
    category: "Чашки",
    material: "Керамика",
    dimensions: "Объём: 400 мл, Высота: 11 см",
    inStock: true,
  },
  // Тарелки
  {
    id: 8,
    name: "Тарелка «Белый квинтет»",
    price: 6500,
    image: "https://images.unsplash.com/photo-1740329362227-45c2f46a1f66?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjZXJhbWljJTIwcGxhdGVzJTIwdGFibGV3YXJlJTIwbW9kZXJuJTIwaW50ZXJpb3J8ZW58MXx8fHwxNzc3ODM5NDE4fDA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Набор из 5 фарфоровых тарелок разного диаметра с тонкой золотой каймой. Превратит любой обед в особый ритуал.",
    category: "Тарелки",
    material: "Фарфор",
    dimensions: "Диаметры: 18, 21, 24, 27, 30 см",
    inStock: true,
    isBestseller: true,
  },
  {
    id: 9,
    name: "Тарелка «Аметист»",
    price: 2800,
    image: "https://images.unsplash.com/photo-1723779234518-69a44224dc88?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHw5fHxjZXJhbWljJTIwcG9yY2VsYWluJTIwcG90dGVyeXxlbnwxfHx8fDE3Nzc4Mzg5MDR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Одиночная обеденная тарелка с уникальным лавандово-серым покрытием. Каждая тарелка — одна в своём роде из-за непредсказуемого обжига.",
    category: "Тарелки",
    material: "Керамика",
    dimensions: "Диаметр: 27 см, Глубина: 2 см",
    inStock: true,
    isNew: true,
  },
  {
    id: 10,
    name: "Сервиз «Классика»",
    price: 15900,
    image: "https://images.unsplash.com/photo-1723779233230-1554e448c258?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHw2fHxjZXJhbWljJTIwcG9yY2VsYWluJTIwcG90dGVyeXxlbnwxfHx8fDE3Nzc4Mzg5MDR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Полный обеденный сервиз на 6 персон из белоснежного фарфора. 24 предмета: тарелки трёх видов, суповые миски, блюдца. Вечная классика.",
    category: "Тарелки",
    material: "Фарфор",
    dimensions: "24 предмета, тарелки Ø18–27 см",
    inStock: true,
  },
  // Декор
  {
    id: 11,
    name: "Чаша «Земля и небо»",
    price: 3200,
    image: "https://images.unsplash.com/photo-1762541088571-34a2949af8a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjZXJhbWljJTIwYm93bCUyMGVhcnRoeSUyMG5hdHVyYWwlMjB0ZXh0dXJlfGVufDF8fHx8MTc3NzgzOTQxN3ww&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Широкая декоративная чаша с природной текстурой. Двуслойная глазурь создаёт эффект неба, отражённого в земле. Подходит как для декора, так и для фруктов.",
    category: "Декор",
    material: "Керамика",
    dimensions: "Диаметр: 35 см, Высота: 10 см",
    inStock: true,
    isBestseller: true,
  },
  {
    id: 12,
    name: "Ваза «Кобальт»",
    price: 5800,
    image: "https://images.unsplash.com/photo-1723779233992-74944a7c21ba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHw4fHxjZXJhbWljJTIwcG9yY2VsYWluJTIwcG90dGVyeXxlbnwxfHx8fDE3Nzc4Mzg5MDR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Классическая сине-белая фарфоровая ваза в традиции Делфт и Гжели. Глубокий кобальтовый орнамент на снежно-белом фоне — квинтэссенция фарфорового искусства.",
    category: "Декор",
    material: "Фарфор",
    dimensions: "Высота: 33 см, Диаметр: 17 см",
    inStock: true,
  },
  {
    id: 13,
    name: "Скульптура «Луна»",
    price: 9500,
    image: "https://images.unsplash.com/photo-1760895535234-2c39c57cf187?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3JjZWxhaW4lMjB2YXNlJTIwd2hpdGUlMjBtaW5pbWFsJTIwbHV4dXJ5fGVufDF8fHx8MTc3NzgzOTQxNXww&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Минималистичная скульптурная ваза — идеальный круг из тончайшего фарфора. Произведение искусства, которое меняет свой облик в зависимости от угла освещения.",
    category: "Декор",
    material: "Фарфор",
    dimensions: "Диаметр: 22 см, Глубина: 8 см",
    inStock: true,
    isNew: true,
  },
];

export const categories = ["Все", "Вазы", "Чашки", "Тарелки", "Декор"];
